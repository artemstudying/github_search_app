import React, { Component } from 'react';
import SearchPage from './Components/SearchPage/SearchPage'

class App extends Component {
  render() {
    return (
      <SearchPage />
    );
  }
}

export default App;
